This is the source code for the xpad plugin. See the [main readme](../README.md)
for supported controllers, installation, configuration and build instructions.
